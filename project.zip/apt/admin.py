from django.contrib import admin
from .models import data
# Register your models here.
admin.site.register(data)