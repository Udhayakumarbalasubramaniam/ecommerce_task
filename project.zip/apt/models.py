from django.db import models

class data(models.Model):
    Name=models.CharField(max_length=20,default="")
    email=models.EmailField(default="")
    password=models.CharField(max_length=30,default="")
    