from django.urls import path
from . import views 

urlpatterns=[
    path('',views.Indexpage,name='emplty'),
    path('signin/',views.Signup,name='Sign_up'),
    path('home/',views.Home,name='home'),
    path('products/',views.product,name='products'),
    path('contact/',views.contact,name='contactus'),
    
]