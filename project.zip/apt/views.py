from django.shortcuts import render
from django.http import HttpRequest,HttpResponse,HttpResponseRedirect
# Create your views here.
def empty(request):
    return HttpResponse("Hello Everyone I am going to to make the word <b>bold</b> in bold<label <h ref='www.youtube.com> Hello>hello</label>")
def Indexpage(request):
    return render(request,'index.html')
def Home(request):
    return render(request,'home.html')
def Signup(request):
    return render(request,'signin.html')
def product(request):
    return render(request,'products.html')
def contact(request):
    return render(request,'contact.html')